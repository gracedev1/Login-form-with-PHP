<!DOCTYPE html>
<html>
<head>
    <title>Login page</title>
</head>
<body>

    <center>
            <p>Login</p>

         <form action="login process.php" method="POST">

                   <input type="text" id="user" name="username" placeholder="username"/><br><br>
                   <input type="Password" id="pass" name="password" placeholder="password"/><br><br>
                   <button type="submit" id="btn" name="login" default>login</button>
                   
         </form>

    </center>

</body>
</html>